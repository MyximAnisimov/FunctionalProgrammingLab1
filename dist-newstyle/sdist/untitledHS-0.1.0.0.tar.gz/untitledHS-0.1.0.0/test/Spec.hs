module Spec where

import Test.HUnit
import Task20_Recursions(factorialFunc)

import qualified System.Exit as Exit
test1 :: Test
test1 = TestCase (assertEqual "Check tail recursion" 93326215443944152681699238856266700490715968264381621468592963895217599993229915608941463976156518286253697920827223758251185210916864000000000000000000000000 (factorialFunc 100))

tests :: Test
tests = TestList [TestLabel "test1" test1]

-- main :: IO ()
-- main = do
--     result <- runTestTT tests
--     print result
